Content: w 960 - h 500
Logo: w 80 - h 35